Each .abf file contains ten V-ramp sweeps. The mean of these sweeps 
was analysed as described by Murphy et al. (2023). See that paper 
for the experimental details including the V-ramp protocols. The .abf 
files can be opened with the free program ClampFit from Molecular 
Devices (we used version 10.7).
